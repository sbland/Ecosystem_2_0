//----------------------------------------------
//
//      Copyright © 2013 - 2014  Illogika
//----------------------------------------------
using UnityEngine;
using System.Collections;
using HeavyDutyInspector;

public class ExampleButton : MonoBehaviour {

	[Comment("Add buttons and call functions by name using reflection", CommentType.Info, true)]
	public bool comment;
	
	[Button("Reset Position", "ResetPosition", true)]
	public bool hidden;

	[Comment("Or create buttons with an image by specifying its path.", CommentType.Info, true)]
	public bool comment2;

	[ImageButton("Illogika/HeavyDutyInspector/Examples/Textures/illogika-logo.png", "ResetPosition", true)]
	public bool hidden2;

	void ResetPosition()
	{
		transform.position = Vector3.zero;
	}
}
